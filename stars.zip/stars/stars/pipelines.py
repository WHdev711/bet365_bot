# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import scrapy
from stars.spiders.stars_spider import StarsSpider
from stars.items import CompetitionItem,EventItem,BookieOddItem,Sport,selections_db
from scrapy.utils.project import get_project_settings
from time import sleep
import sys
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
SETTINGS = get_project_settings()

class StarsPipeline:
    all_bookies = {54:"sports.pokerstarssports.it"}

    def open_spider(self,spider):
        self.engine = create_engine("mysql://%s:%s@%s/%s?charset=utf8mb4&use_unicode=0"
                       %(SETTINGS["DB_USER"], SETTINGS["DB_PASS"], SETTINGS["DB_HOST"], SETTINGS["DB_NAME"]),
                       echo=False,
                       pool_recycle=1800)

        self.db = scoped_session(sessionmaker(autocommit=False,
                                        autoflush=False,
                                        bind=self.engine))

    def close_spider(self, spider):
        stmt = 'update bookie_odds set hidden=1 where bookie_id in ({0}) \
                        and cycle in ( \
                            select * from ( \
                                select cycle \
                                from bookie_odds \
                                where bookie_id in ({0}) \
                                group by cycle order by cycle desc limit 100 offset 1\
                            ) a)'.format(",".join([str(k) for k in self.all_bookies.keys()]))
        self.db.execute(stmt)
        self.db.commit()
        self.db.close()

    def process_item(self, item, spider):
        
        if isinstance(item,CompetitionItem):
            
            stmt = 'insert into competitions (\
                        competition,\
                        country,\
                        bookie_id,\
                        sport_id,\
                        params) values ("{0}","{1}", {2}, {3}, "{4}")\
                            on duplicate key update \
                                competition="{0}",\
                                country="{1}",\
                                update_time = NOW()\
                                    returning id'.format(
                                        item["competition_name"],
                                        item["country_name"],
                                        item["bookie_id"],
                                        item["sport_id"],
                                        item["params"]) 
            
            result = self.db.execute(stmt)
            self.db.commit()
            competition_id = result.fetchone()[0]
            
            
            url = "https://sports.pokerstarssports.it/sportsbook/v1/api/getCompetitionEvents?competitionId={0}&includeOutrights=false&channelId=3&locale=it-it&siteId=16".format(item["params"])
            r = scrapy.http.JsonRequest(url=url, callback=StarsSpider().parse_events, dont_filter=True,cb_kwargs={"competition_id":competition_id,"sport_id":item["sport_id"],"bookie_id":item["bookie_id"]})
            spider.crawler.engine.crawl(r, spider)

        elif isinstance(item,EventItem):
            # params = '{\\"event_id\\":\\"'+str(item["event_id"])+'\\",\\"params\\":\\"'+str(item["params"])+'\\"}'
            stmt = 'insert into events (\
                        event,\
                        open_date,\
                        betradar_id,\
                        competition_id,\
                        bookie_id,\
                        params) values ("{0}","{1}", {2}, {3}, {4}, "{5}")\
                            on duplicate key update\
                                event = "{0}",\
                                open_date = "{1}",\
                                update_time = NOW()\
                                    returning id'.format(
                                        item["event"],
                                        item["open_date"],
                                        item["betradar_id"],
                                        item["competition_id"],
                                        item["bookie_id"],
                                        str(item["event_id"]))
                                    
            result = self.db.execute(stmt)
            event_id = result.fetchone()[0]

            if len(item["all_book_odds"]):
                stmt = "insert into bookie_odds (\
                                        event_id,\
                                        market_id,\
                                        selection_id,\
                                        odds,\
                                        bookie_id,\
                                        cycle\
                                        ) values "

                for bet_type,odd_val in item["all_book_odds"].items():
                    bt = selections_db.get(bet_type,None)
                    if bt:
                        sid = bt["selection_id"]
                        mid = bt["market_id"]
                        stmt += " ({0},{1},{2},{3},{4},{5}),".format(
                                        event_id,
                                        mid,
                                        sid,
                                        odd_val,
                                        item["bookie_id"],
                                        item["ciclo"])

                stmt = stmt.strip(",")
                stmt += " on duplicate key update odds=VALUES(odds), cycle=VALUES(cycle),hidden=0"
                
                self.db.execute(stmt)
                self.db.commit()

            if item["sport_id"] == Sport.CALCIO.value:
                url = "https://sports.pokerstarssports.it/sportsbook/v1/api/getEvent?eventId={0}&channelId=3&locale=it-it&siteId=16".format(item["event_id"])
                r = scrapy.http.JsonRequest(url=url, callback=StarsSpider().parse_odds, dont_filter=True,cb_kwargs={"event_id":event_id,"event_name":item["event"],"bookie_id":item["bookie_id"]})
                spider.crawler.engine.crawl(r, spider)

        elif isinstance(item,BookieOddItem):
            stmt = "insert into bookie_odds (\
                        event_id,\
                        market_id,\
                        selection_id,\
                        odds,\
                        bookie_id,cycle) values ({0},{1},{2},{3},{4},{5})\
                            on duplicate key update\
                            odds={3},\
                            hidden=0,\
                            cycle={5}\
                        ".format(
                            item["event_id"],
                            item["market_id"],
                            item["selection_id"],
                            item["odd_value"],
                            item["bookie_id"],
                            item["ciclo"])
                        
            self.db.execute(stmt)
            self.db.commit()

        return item