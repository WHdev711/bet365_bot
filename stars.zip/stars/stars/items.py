# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from enum import Enum

class CompetitionItem(scrapy.Item):
    competition_name = scrapy.Field()
    country_name = scrapy.Field()
    params = scrapy.Field()
    sport_id = scrapy.Field()
    bookie_id = scrapy.Field()

class EventItem(scrapy.Item):
    event = scrapy.Field()
    event_id = scrapy.Field()
    open_date = scrapy.Field()
    competition_id = scrapy.Field()
    betradar_id = scrapy.Field()
    sport_id = scrapy.Field()
    params = scrapy.Field()
    bookie_id = scrapy.Field()
    ciclo = scrapy.Field()
    all_book_odds = scrapy.Field()

class BookieOddItem(scrapy.Item):
    event_id = scrapy.Field()
    market_id = scrapy.Field()
    selection_id = scrapy.Field()
    odd_value = scrapy.Field()
    game_play = scrapy.Field()
    bookie_id = scrapy.Field()
    ciclo = scrapy.Field()


class Market(Enum):
    M_1X2=1
    FH_1X2=2
    SH_1X2=3
    M_12=4
    DC=5
    FH_DC=6
    SH_DC=7
    OVER_UNDER=8
    TEAM1_OVER_UNDER=9
    TEAM2_OVER_UNDER=10
    FH_OVER_UNDER=11
    SH_OVER_UNDER=12
    GNG=13
    FH_GNG=14
    SH_GNG=15
    CORRECT_SCORE=16
    EVEN_ODD=17
    HT_FT=18
    PENALTY_NOPENALTY=19
    SET1_HH = 20
    SET2_HH = 21
    TB_OU = 22
    GAMES_OU = 23
    SET1_GAMES_OU = 24
    SET2_GAMES_OU = 25
    PLAYER1_GAMES_OU = 26
    PLAYER2_GAMES_OU = 27
    
class Exchange(Enum):
    BETFAIR=1
    BETFLAG=2
    
class Sport(Enum):
    CALCIO=1
    TENNIS=2
    BASKET=3
    TENNISTAVOLO=4
    ESPORTS=5
    
class Selection(Enum):
    HOME=1
    AWAY=2
    DRAW=3
    FH_HOME=4
    FH_AWAY=5
    FH_DRAW=6
    SH_HOME=7
    SH_AWAY=8
    SH_DRAW=9
    EVEN=10
    ODD=11
    CS_00=12
    CS_01=13
    CS_02=14
    CS_03=15
    CS_04=16
    CS_05=17
    CS_06=18
    CS_07=19
    CS_08=20
    CS_09=21
    CS_10=22
    CS_11=23
    CS_12=24
    CS_13=25
    CS_14=26
    CS_15=27
    CS_16=28
    CS_17=29
    CS_18=30
    CS_19=31
    CS_20=32
    CS_21=33
    CS_22=34
    CS_23=35
    CS_24=36
    CS_25=37
    CS_26=38
    CS_27=39
    CS_28=40
    CS_29=41
    CS_30=42
    CS_31=43
    CS_32=44
    CS_33=45
    CS_34=46
    CS_35=47
    CS_36=48
    CS_37=49
    CS_38=50
    CS_40=51
    CS_41=52
    CS_42=53
    CS_43=54
    CS_44=55
    CS_45=56
    CS_46=57
    CS_47=58
    CS_48=59
    CS_50=60
    CS_51=61
    CS_52=62
    CS_53=63
    CS_54=64
    CS_55=65
    CS_56=66
    CS_60=67
    CS_61=68
    CS_62=69
    CS_63=70
    CS_64=71
    CS_65=72
    CS_70=73
    CS_71=74
    CS_72=75
    CS_73=76
    CS_74=77
    CS_80=78
    CS_81=79
    CS_82=80
    CS_83=81
    CS_84=82
    CS_90=83
    CS_91=84
    CS_92=85
    CS_93=86
    CS_94=87
    CS_95=88
    CS_96=89
    CS_97=90
    CS_98=91
    CS_99=92
    DC_HOME_AWAY=93
    DC_HOME_DRAW=94
    DC_DRAW_AWAY=95
    FH_DC_HOME_AWAY=96
    FH_DC_HOME_DRAW=97
    FH_DC_DRAW_AWAY=98
    SH_DC_HOME_AWAY=99
    SH_DC_HOME_DRAW=100
    SH_DC_DRAW_AWAY=101
    PENALTY=102
    NO_PENALTY=103
    GOAL=104
    NO_GOAL=105
    FH_GOAL=106
    FH_NO_GOAL=107
    SH_GOAL=108
    SH_NO_GOAL=109
    OVER_05=110
    OVER_15=111
    OVER_25=112
    OVER_35=113
    OVER_45=114
    OVER_55=115
    OVER_65=116
    OVER_75=117
    OVER_85=118
    OVER_95=119
    UNDER_05=120
    UNDER_15=121
    UNDER_25=122
    UNDER_35=123
    UNDER_45=124
    UNDER_55=125
    UNDER_65=126
    UNDER_75=127
    UNDER_85=128
    UNDER_95=129
    FH_OVER_05=130
    FH_OVER_15=131
    FH_OVER_25=132
    FH_OVER_35=133
    FH_OVER_45=134
    FH_OVER_55=135
    FH_OVER_65=136
    FH_OVER_75=137
    FH_OVER_85=138
    FH_OVER_95=139
    FH_UNDER_05=140
    FH_UNDER_15=141
    FH_UNDER_25=142
    FH_UNDER_35=143
    FH_UNDER_45=144
    FH_UNDER_55=145
    FH_UNDER_65=146
    FH_UNDER_75=147
    FH_UNDER_85=148
    FH_UNDER_95=149
    SH_OVER_05=150
    SH_OVER_15=151
    SH_OVER_25=152
    SH_OVER_35=153
    SH_OVER_45=154
    SH_OVER_55=155
    SH_OVER_65=156
    SH_OVER_75=157
    SH_OVER_85=158
    SH_OVER_95=159
    SH_UNDER_05=160
    SH_UNDER_15=161
    SH_UNDER_25=162
    SH_UNDER_35=163
    SH_UNDER_45=164
    SH_UNDER_55=165
    SH_UNDER_65=166
    SH_UNDER_75=167
    SH_UNDER_85=168
    SH_UNDER_95=169
    TEAM1_OVER_05=170
    TEAM1_OVER_15=171
    TEAM1_OVER_25=172
    TEAM1_OVER_35=173
    TEAM1_OVER_45=174
    TEAM1_OVER_55=175
    TEAM1_OVER_65=176
    TEAM1_OVER_75=177
    TEAM1_OVER_85=178
    TEAM1_OVER_95=179
    TEAM1_UNDER_05=180
    TEAM1_UNDER_15=181
    TEAM1_UNDER_25=182
    TEAM1_UNDER_35=183
    TEAM1_UNDER_45=184
    TEAM1_UNDER_55=185
    TEAM1_UNDER_65=186
    TEAM1_UNDER_75=187
    TEAM1_UNDER_85=188
    TEAM1_UNDER_95=189
    TEAM2_OVER_05=190
    TEAM2_OVER_15=191
    TEAM2_OVER_25=192
    TEAM2_OVER_35=193
    TEAM2_OVER_45=194
    TEAM2_OVER_55=195
    TEAM2_OVER_65=196
    TEAM2_OVER_75=197
    TEAM2_OVER_85=198
    TEAM2_OVER_95=199
    TEAM2_UNDER_05=200
    TEAM2_UNDER_15=201
    TEAM2_UNDER_25=202
    TEAM2_UNDER_35=203
    TEAM2_UNDER_45=204
    TEAM2_UNDER_55=205
    TEAM2_UNDER_65=206
    TEAM2_UNDER_75=207
    TEAM2_UNDER_85=208
    TEAM2_UNDER_95=209
    HT_FT_AWAY_AWAY = 216
    HT_FT_AWAY_DRAW = 217
    HT_FT_AWAY_HOME = 218
    HT_FT_DRAW_AWAY = 219
    HT_FT_DRAW_DRAW = 220
    HT_FT_DRAW_HOME = 221
    HT_FT_HOME_AWAY = 222
    HT_FT_HOME_DRAW = 223
    HT_FT_HOME_HOME = 224
    SET1_HOME=225  
    SET1_AWAY=226     
    SET2_AWAY=227     
    SET2_HOME=228 
    TB_OVER_05=229    
    TB_UNDER_05=230
    GAMES_OVER_165=231
    GAMES_OVER_175=232
    GAMES_OVER_185=233
    GAMES_OVER_195=234
    GAMES_OVER_205=235
    GAMES_OVER_215=236
    GAMES_OVER_225=237
    GAMES_OVER_235=238
    GAMES_OVER_245=239
    GAMES_OVER_255=240
    GAMES_OVER_265=241
    GAMES_OVER_275=242
    GAMES_OVER_285=243
    GAMES_OVER_295=244
    GAMES_OVER_305=245
    GAMES_OVER_315=246
    GAMES_OVER_335=247
    GAMES_OVER_345=248
    GAMES_OVER_355=249
    GAMES_OVER_365=250
    GAMES_OVER_375=251
    GAMES_OVER_385=252
    GAMES_OVER_395=253
    GAMES_OVER_405=254
    GAMES_OVER_415=255
    GAMES_OVER_425=256
    GAMES_OVER_435=257
    GAMES_OVER_455=258
    GAMES_OVER_465=259
    GAMES_UNDER_165=260
    GAMES_UNDER_175=261
    GAMES_UNDER_185=262
    GAMES_UNDER_195=263
    GAMES_UNDER_205=264
    GAMES_UNDER_215=265
    GAMES_UNDER_225=266
    GAMES_UNDER_235=267
    GAMES_UNDER_245=268
    GAMES_UNDER_255=269
    GAMES_UNDER_265=270
    GAMES_UNDER_275=271
    GAMES_UNDER_285=272
    GAMES_UNDER_295=273
    GAMES_UNDER_305=274
    GAMES_UNDER_315=275
    GAMES_UNDER_335=276
    GAMES_UNDER_345=277
    GAMES_UNDER_355=278
    GAMES_UNDER_365=279
    GAMES_UNDER_375=280
    GAMES_UNDER_385=281
    GAMES_UNDER_395=282
    GAMES_UNDER_405=283
    GAMES_UNDER_415=284
    GAMES_UNDER_425=285
    GAMES_UNDER_435=286
    GAMES_UNDER_455=287
    GAMES_UNDER_465=288
    PLAYER1_GAMES_OVER_105=289
    PLAYER1_GAMES_OVER_115=290
    PLAYER1_GAMES_OVER_125=291
    PLAYER1_GAMES_OVER_185=292
    PLAYER1_GAMES_OVER_205=293
    PLAYER1_GAMES_UNDER_105=294
    PLAYER1_GAMES_UNDER_115=295
    PLAYER1_GAMES_UNDER_125=296
    PLAYER1_GAMES_UNDER_185=297
    PLAYER1_GAMES_UNDER_205=298
    PLAYER2_GAMES_OVER_105=299
    PLAYER2_GAMES_OVER_115=300
    PLAYER2_GAMES_OVER_125=301
    PLAYER2_GAMES_OVER_165=302
    PLAYER2_GAMES_OVER_205=303
    PLAYER2_GAMES_OVER_75=304
    PLAYER2_GAMES_OVER_85=305
    PLAYER2_GAMES_OVER_95=306 
    PLAYER2_GAMES_UNDER_105=307
    PLAYER2_GAMES_UNDER_115=308
    PLAYER2_GAMES_UNDER_125=309
    PLAYER2_GAMES_UNDER_165=310
    PLAYER2_GAMES_UNDER_205=311
    PLAYER2_GAMES_UNDER_75=312
    PLAYER2_GAMES_UNDER_85=313
    PLAYER2_GAMES_UNDER_95=314
    SET1_GAMES_OVER_105=315
    SET1_GAMES_OVER_125=316   
    SET1_GAMES_OVER_65=317
    SET1_GAMES_OVER_75=318    
    SET1_GAMES_OVER_85=319    
    SET1_GAMES_OVER_95=320    
    SET1_GAMES_UNDER_105=321  
    SET1_GAMES_UNDER_125=322  
    SET1_GAMES_UNDER_65=323   
    SET1_GAMES_UNDER_75=324   
    SET1_GAMES_UNDER_85=325   
    SET1_GAMES_UNDER_95=326 

selections_db = {
        "home_12": {"selection_id":Selection.HOME.value,"market_id":Market.M_12.value},
        "away_12": {"selection_id":Selection.AWAY.value,"market_id":Market.M_12.value},
        "home": {"selection_id":Selection.HOME.value,"market_id":Market.M_1X2.value},
        "away": {"selection_id":Selection.AWAY.value,"market_id":Market.M_1X2.value},
        "draw": {"selection_id":Selection.DRAW.value,"market_id":Market.M_1X2.value},
        "fh_home": {"selection_id":Selection.FH_HOME.value,"market_id":Market.FH_1X2.value},
        "fh_away": {"selection_id":Selection.FH_AWAY.value,"market_id":Market.FH_1X2.value},
        "fh_draw": {"selection_id":Selection.FH_DRAW.value,"market_id":Market.FH_1X2.value},
        "sh_home": {"selection_id":Selection.SH_HOME.value,"market_id":Market.SH_1X2.value},
        "sh_away": {"selection_id":Selection.SH_AWAY.value,"market_id":Market.SH_1X2.value},
        "sh_draw": {"selection_id":Selection.SH_DRAW.value,"market_id":Market.SH_1X2.value},
        "even": {"selection_id":Selection.EVEN.value,"market_id":Market.EVEN_ODD.value},
        "odd": {"selection_id":Selection.ODD.value,"market_id":Market.EVEN_ODD.value},
        "cs_00": {"selection_id":Selection.CS_00.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_01": {"selection_id":Selection.CS_01.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_02": {"selection_id":Selection.CS_02.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_03": {"selection_id":Selection.CS_03.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_04": {"selection_id":Selection.CS_04.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_05": {"selection_id":Selection.CS_05.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_06": {"selection_id":Selection.CS_06.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_07": {"selection_id":Selection.CS_07.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_08": {"selection_id":Selection.CS_08.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_09": {"selection_id":Selection.CS_09.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_10": {"selection_id":Selection.CS_10.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_11": {"selection_id":Selection.CS_11.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_12": {"selection_id":Selection.CS_12.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_13": {"selection_id":Selection.CS_13.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_14": {"selection_id":Selection.CS_14.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_15": {"selection_id":Selection.CS_15.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_16": {"selection_id":Selection.CS_16.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_17": {"selection_id":Selection.CS_17.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_18": {"selection_id":Selection.CS_18.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_19": {"selection_id":Selection.CS_19.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_20": {"selection_id":Selection.CS_20.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_21": {"selection_id":Selection.CS_21.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_22": {"selection_id":Selection.CS_22.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_23": {"selection_id":Selection.CS_23.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_24": {"selection_id":Selection.CS_24.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_25": {"selection_id":Selection.CS_25.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_26": {"selection_id":Selection.CS_26.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_27": {"selection_id":Selection.CS_27.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_28": {"selection_id":Selection.CS_28.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_29": {"selection_id":Selection.CS_29.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_30": {"selection_id":Selection.CS_30.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_31": {"selection_id":Selection.CS_31.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_32": {"selection_id":Selection.CS_32.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_33": {"selection_id":Selection.CS_33.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_34": {"selection_id":Selection.CS_34.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_35": {"selection_id":Selection.CS_35.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_36": {"selection_id":Selection.CS_36.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_37": {"selection_id":Selection.CS_37.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_38": {"selection_id":Selection.CS_38.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_40": {"selection_id":Selection.CS_40.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_41": {"selection_id":Selection.CS_41.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_42": {"selection_id":Selection.CS_42.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_43": {"selection_id":Selection.CS_43.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_44": {"selection_id":Selection.CS_44.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_45": {"selection_id":Selection.CS_45.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_46": {"selection_id":Selection.CS_46.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_47": {"selection_id":Selection.CS_47.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_48": {"selection_id":Selection.CS_48.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_50": {"selection_id":Selection.CS_50.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_51": {"selection_id":Selection.CS_51.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_52": {"selection_id":Selection.CS_52.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_53": {"selection_id":Selection.CS_53.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_54": {"selection_id":Selection.CS_54.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_55": {"selection_id":Selection.CS_55.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_56": {"selection_id":Selection.CS_56.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_60": {"selection_id":Selection.CS_60.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_61": {"selection_id":Selection.CS_61.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_62": {"selection_id":Selection.CS_62.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_63": {"selection_id":Selection.CS_63.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_64": {"selection_id":Selection.CS_64.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_65": {"selection_id":Selection.CS_65.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_70": {"selection_id":Selection.CS_70.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_71": {"selection_id":Selection.CS_71.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_72": {"selection_id":Selection.CS_72.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_73": {"selection_id":Selection.CS_73.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_74": {"selection_id":Selection.CS_74.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_80": {"selection_id":Selection.CS_80.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_81": {"selection_id":Selection.CS_81.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_82": {"selection_id":Selection.CS_82.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_83": {"selection_id":Selection.CS_83.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_84": {"selection_id":Selection.CS_84.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_90": {"selection_id":Selection.CS_90.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_91": {"selection_id":Selection.CS_91.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_92": {"selection_id":Selection.CS_92.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_93": {"selection_id":Selection.CS_93.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_94": {"selection_id":Selection.CS_94.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_95": {"selection_id":Selection.CS_95.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_96": {"selection_id":Selection.CS_96.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_97": {"selection_id":Selection.CS_97.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_98": {"selection_id":Selection.CS_98.value,"market_id":Market.CORRECT_SCORE.value},
        "cs_99": {"selection_id":Selection.CS_99.value,"market_id":Market.CORRECT_SCORE.value},
        "dc_home_away": {"selection_id":Selection.DC_HOME_AWAY.value,"market_id":Market.DC.value},
        "dc_home_draw": {"selection_id":Selection.DC_HOME_DRAW.value,"market_id":Market.DC.value},
        "dc_draw_away": {"selection_id":Selection.DC_DRAW_AWAY.value,"market_id":Market.DC.value},
        "fh_dc_home_away": {"selection_id":Selection.FH_DC_HOME_AWAY.value,"market_id":Market.FH_DC.value},
        "fh_dc_home_draw": {"selection_id":Selection.FH_DC_HOME_DRAW.value,"market_id":Market.FH_DC.value},
        "fh_dc_draw_away": {"selection_id":Selection.FH_DC_DRAW_AWAY.value,"market_id":Market.FH_DC.value},
        "sh_dc_home_away": {"selection_id":Selection.SH_DC_HOME_AWAY.value,"market_id":Market.SH_DC.value},
        "sh_dc_home_draw": {"selection_id":Selection.SH_DC_HOME_DRAW.value,"market_id":Market.SH_DC.value},
        "sh_dc_draw_away": {"selection_id":Selection.SH_DC_DRAW_AWAY.value,"market_id":Market.SH_DC.value},
        "penalty": {"selection_id":Selection.PENALTY.value,"market_id":Market.PENALTY_NOPENALTY.value},
        "no_penalty": {"selection_id":Selection.NO_PENALTY.value,"market_id":Market.PENALTY_NOPENALTY.value},
        "goal": {"selection_id":Selection.GOAL.value,"market_id":Market.GNG.value},
        "no_goal": {"selection_id":Selection.NO_GOAL.value,"market_id":Market.GNG.value},
        "fh_goal": {"selection_id":Selection.FH_GOAL.value,"market_id":Market.FH_GNG.value},
        "fh_no_goal": {"selection_id":Selection.FH_NO_GOAL.value,"market_id":Market.FH_GNG.value},
        "sh_goal": {"selection_id":Selection.SH_GOAL.value,"market_id":Market.SH_GNG.value},
        "sh_no_goal": {"selection_id":Selection.SH_NO_GOAL.value,"market_id":Market.SH_GNG.value},
        "over_05": {"selection_id":Selection.OVER_05.value,"market_id":Market.OVER_UNDER.value},
        "over_15": {"selection_id":Selection.OVER_15.value,"market_id":Market.OVER_UNDER.value},
        "over_25": {"selection_id":Selection.OVER_25.value,"market_id":Market.OVER_UNDER.value},
        "over_35": {"selection_id":Selection.OVER_35.value,"market_id":Market.OVER_UNDER.value},
        "over_45": {"selection_id":Selection.OVER_45.value,"market_id":Market.OVER_UNDER.value},
        "over_55": {"selection_id":Selection.OVER_55.value,"market_id":Market.OVER_UNDER.value},
        "over_65": {"selection_id":Selection.OVER_65.value,"market_id":Market.OVER_UNDER.value},
        "over_75": {"selection_id":Selection.OVER_75.value,"market_id":Market.OVER_UNDER.value},
        "over_85": {"selection_id":Selection.OVER_85.value,"market_id":Market.OVER_UNDER.value},
        "over_95": {"selection_id":Selection.OVER_95.value,"market_id":Market.OVER_UNDER.value},
        "under_05": {"selection_id":Selection.UNDER_05.value,"market_id":Market.OVER_UNDER.value},
        "under_15": {"selection_id":Selection.UNDER_15.value,"market_id":Market.OVER_UNDER.value},
        "under_25": {"selection_id":Selection.UNDER_25.value,"market_id":Market.OVER_UNDER.value},
        "under_35": {"selection_id":Selection.UNDER_35.value,"market_id":Market.OVER_UNDER.value},
        "under_45": {"selection_id":Selection.UNDER_45.value,"market_id":Market.OVER_UNDER.value},
        "under_55": {"selection_id":Selection.UNDER_55.value,"market_id":Market.OVER_UNDER.value},
        "under_65": {"selection_id":Selection.UNDER_65.value,"market_id":Market.OVER_UNDER.value},
        "under_75": {"selection_id":Selection.UNDER_75.value,"market_id":Market.OVER_UNDER.value},
        "under_85": {"selection_id":Selection.UNDER_85.value,"market_id":Market.OVER_UNDER.value},
        "under_95": {"selection_id":Selection.UNDER_95.value,"market_id":Market.OVER_UNDER.value},
        "fh_over_05": {"selection_id":Selection.FH_OVER_05.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_over_15": {"selection_id":Selection.FH_OVER_15.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_over_25": {"selection_id":Selection.FH_OVER_25.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_over_35": {"selection_id":Selection.FH_OVER_35.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_over_45": {"selection_id":Selection.FH_OVER_45.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_over_55": {"selection_id":Selection.FH_OVER_55.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_over_65": {"selection_id":Selection.FH_OVER_65.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_over_75": {"selection_id":Selection.FH_OVER_75.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_over_85": {"selection_id":Selection.FH_OVER_85.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_over_95": {"selection_id":Selection.FH_OVER_95.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_05": {"selection_id":Selection.FH_UNDER_05.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_15": {"selection_id":Selection.FH_UNDER_15.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_25": {"selection_id":Selection.FH_UNDER_25.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_35": {"selection_id":Selection.FH_UNDER_35.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_45": {"selection_id":Selection.FH_UNDER_45.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_55": {"selection_id":Selection.FH_UNDER_55.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_65": {"selection_id":Selection.FH_UNDER_65.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_75": {"selection_id":Selection.FH_UNDER_75.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_85": {"selection_id":Selection.FH_UNDER_85.value,"market_id":Market.FH_OVER_UNDER.value},
        "fh_under_95": {"selection_id":Selection.FH_UNDER_95.value,"market_id":Market.FH_OVER_UNDER.value},
        "sh_over_05": {"selection_id":Selection.SH_OVER_05.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_over_15": {"selection_id":Selection.SH_OVER_15.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_over_25": {"selection_id":Selection.SH_OVER_25.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_over_35": {"selection_id":Selection.SH_OVER_35.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_over_45": {"selection_id":Selection.SH_OVER_45.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_over_55": {"selection_id":Selection.SH_OVER_55.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_over_65": {"selection_id":Selection.SH_OVER_65.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_over_75": {"selection_id":Selection.SH_OVER_75.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_over_85": {"selection_id":Selection.SH_OVER_85.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_over_95": {"selection_id":Selection.SH_OVER_95.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_05": {"selection_id":Selection.SH_UNDER_05.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_15": {"selection_id":Selection.SH_UNDER_15.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_25": {"selection_id":Selection.SH_UNDER_25.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_35": {"selection_id":Selection.SH_UNDER_35.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_45": {"selection_id":Selection.SH_UNDER_45.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_55": {"selection_id":Selection.SH_UNDER_55.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_65": {"selection_id":Selection.SH_UNDER_65.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_75": {"selection_id":Selection.SH_UNDER_75.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_85": {"selection_id":Selection.SH_UNDER_85.value,"market_id":Market.SH_OVER_UNDER.value},
        "sh_under_95": {"selection_id":Selection.SH_UNDER_95.value,"market_id":Market.SH_OVER_UNDER.value},
        "team1_over_05": {"selection_id":Selection.TEAM1_OVER_05.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_over_15": {"selection_id":Selection.TEAM1_OVER_15.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_over_25": {"selection_id":Selection.TEAM1_OVER_25.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_over_35": {"selection_id":Selection.TEAM1_OVER_35.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_over_45": {"selection_id":Selection.TEAM1_OVER_45.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_over_55": {"selection_id":Selection.TEAM1_OVER_55.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_over_65": {"selection_id":Selection.TEAM1_OVER_65.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_over_75": {"selection_id":Selection.TEAM1_OVER_75.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_over_85": {"selection_id":Selection.TEAM1_OVER_85.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_over_95": {"selection_id":Selection.TEAM1_OVER_95.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_05": {"selection_id":Selection.TEAM1_UNDER_05.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_15": {"selection_id":Selection.TEAM1_UNDER_15.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_25": {"selection_id":Selection.TEAM1_UNDER_25.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_35": {"selection_id":Selection.TEAM1_UNDER_35.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_45": {"selection_id":Selection.TEAM1_UNDER_45.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_55": {"selection_id":Selection.TEAM1_UNDER_55.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_65": {"selection_id":Selection.TEAM1_UNDER_65.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_75": {"selection_id":Selection.TEAM1_UNDER_75.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_85": {"selection_id":Selection.TEAM1_UNDER_85.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team1_under_95": {"selection_id":Selection.TEAM1_UNDER_95.value,"market_id":Market.TEAM1_OVER_UNDER.value},
        "team2_over_05": {"selection_id":Selection.TEAM2_OVER_05.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_over_15": {"selection_id":Selection.TEAM2_OVER_15.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_over_25": {"selection_id":Selection.TEAM2_OVER_25.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_over_35": {"selection_id":Selection.TEAM2_OVER_35.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_over_45": {"selection_id":Selection.TEAM2_OVER_45.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_over_55": {"selection_id":Selection.TEAM2_OVER_55.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_over_65": {"selection_id":Selection.TEAM2_OVER_65.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_over_75": {"selection_id":Selection.TEAM2_OVER_75.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_over_85": {"selection_id":Selection.TEAM2_OVER_85.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_over_95": {"selection_id":Selection.TEAM2_OVER_95.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_05": {"selection_id":Selection.TEAM2_UNDER_05.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_15": {"selection_id":Selection.TEAM2_UNDER_15.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_25": {"selection_id":Selection.TEAM2_UNDER_25.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_35": {"selection_id":Selection.TEAM2_UNDER_35.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_45": {"selection_id":Selection.TEAM2_UNDER_45.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_55": {"selection_id":Selection.TEAM2_UNDER_55.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_65": {"selection_id":Selection.TEAM2_UNDER_65.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_75": {"selection_id":Selection.TEAM2_UNDER_75.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_85": {"selection_id":Selection.TEAM2_UNDER_85.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "team2_under_95": {"selection_id":Selection.TEAM2_UNDER_95.value,"market_id":Market.TEAM2_OVER_UNDER.value},
        "ht_ft_away_away": {"selection_id":Selection.HT_FT_AWAY_AWAY.value,"market_id":Market.HT_FT.value},
        "ht_ft_away_draw": {"selection_id":Selection.HT_FT_AWAY_DRAW.value,"market_id":Market.HT_FT.value},
        "ht_ft_away_home": {"selection_id":Selection.HT_FT_AWAY_HOME.value,"market_id":Market.HT_FT.value},
        "ht_ft_draw_away": {"selection_id":Selection.HT_FT_DRAW_AWAY.value,"market_id":Market.HT_FT.value},
        "ht_ft_draw_draw": {"selection_id":Selection.HT_FT_DRAW_DRAW.value,"market_id":Market.HT_FT.value},
        "ht_ft_draw_home": {"selection_id":Selection.HT_FT_DRAW_HOME.value,"market_id":Market.HT_FT.value},
        "ht_ft_home_away": {"selection_id":Selection.HT_FT_HOME_AWAY.value,"market_id":Market.HT_FT.value},
        "ht_ft_home_draw": {"selection_id":Selection.HT_FT_HOME_DRAW.value,"market_id":Market.HT_FT.value},
        "ht_ft_home_home": {"selection_id":Selection.HT_FT_HOME_HOME.value,"market_id":Market.HT_FT.value},
        "set1_home": {"selection_id":Selection.SET1_HOME.value,"market_id":Market.SET1_HH.value},
        "set1_away": {"selection_id":Selection.SET1_AWAY.value,"market_id":Market.SET1_HH.value},
        "set2_home": {"selection_id":Selection.SET2_HOME.value,"market_id":Market.SET2_HH.value},
        "set2_away": {"selection_id":Selection.SET2_AWAY.value,"market_id":Market.SET2_HH.value},
        "tb_over_05": {"selection_id":Selection.TB_OVER_05.value,"market_id":Market.TB_OU.value},
        "tb_under_05": {"selection_id":Selection.TB_UNDER_05.value,"market_id":Market.TB_OU.value},
        "games_over_165": {"selection_id":Selection.GAMES_OVER_165.value,"market_id":Market.GAMES_OU.value},
        "games_over_175": {"selection_id":Selection.GAMES_OVER_175.value,"market_id":Market.GAMES_OU.value},
        "games_over_185": {"selection_id":Selection.GAMES_OVER_185.value,"market_id":Market.GAMES_OU.value},
        "games_over_195": {"selection_id":Selection.GAMES_OVER_195.value,"market_id":Market.GAMES_OU.value},
        "games_over_205": {"selection_id":Selection.GAMES_OVER_205.value,"market_id":Market.GAMES_OU.value},
        "games_over_215": {"selection_id":Selection.GAMES_OVER_215.value,"market_id":Market.GAMES_OU.value},
        "games_over_225": {"selection_id":Selection.GAMES_OVER_225.value,"market_id":Market.GAMES_OU.value},
        "games_over_235": {"selection_id":Selection.GAMES_OVER_235.value,"market_id":Market.GAMES_OU.value},
        "games_over_245": {"selection_id":Selection.GAMES_OVER_245.value,"market_id":Market.GAMES_OU.value},
        "games_over_255": {"selection_id":Selection.GAMES_OVER_255.value,"market_id":Market.GAMES_OU.value},
        "games_over_265": {"selection_id":Selection.GAMES_OVER_265.value,"market_id":Market.GAMES_OU.value},
        "games_over_275": {"selection_id":Selection.GAMES_OVER_275.value,"market_id":Market.GAMES_OU.value},
        "games_over_285": {"selection_id":Selection.GAMES_OVER_285.value,"market_id":Market.GAMES_OU.value},
        "games_over_295": {"selection_id":Selection.GAMES_OVER_295.value,"market_id":Market.GAMES_OU.value},
        "games_over_305": {"selection_id":Selection.GAMES_OVER_305.value,"market_id":Market.GAMES_OU.value},
        "games_over_315": {"selection_id":Selection.GAMES_OVER_315.value,"market_id":Market.GAMES_OU.value},
        "games_over_335": {"selection_id":Selection.GAMES_OVER_335.value,"market_id":Market.GAMES_OU.value},
        "games_over_345": {"selection_id":Selection.GAMES_OVER_345.value,"market_id":Market.GAMES_OU.value},
        "games_over_355": {"selection_id":Selection.GAMES_OVER_355.value,"market_id":Market.GAMES_OU.value},
        "games_over_365": {"selection_id":Selection.GAMES_OVER_365.value,"market_id":Market.GAMES_OU.value},
        "games_over_375": {"selection_id":Selection.GAMES_OVER_375.value,"market_id":Market.GAMES_OU.value},
        "games_over_385": {"selection_id":Selection.GAMES_OVER_385.value,"market_id":Market.GAMES_OU.value},
        "games_over_395": {"selection_id":Selection.GAMES_OVER_395.value,"market_id":Market.GAMES_OU.value},
        "games_over_405": {"selection_id":Selection.GAMES_OVER_405.value,"market_id":Market.GAMES_OU.value},
        "games_over_415": {"selection_id":Selection.GAMES_OVER_415.value,"market_id":Market.GAMES_OU.value},
        "games_over_425": {"selection_id":Selection.GAMES_OVER_425.value,"market_id":Market.GAMES_OU.value},
        "games_over_435": {"selection_id":Selection.GAMES_OVER_435.value,"market_id":Market.GAMES_OU.value},
        "games_over_455": {"selection_id":Selection.GAMES_OVER_455.value,"market_id":Market.GAMES_OU.value},
        "games_over_465": {"selection_id":Selection.GAMES_OVER_465.value,"market_id":Market.GAMES_OU.value},
        "games_under_165": {"selection_id":Selection.GAMES_UNDER_165.value,"market_id":Market.GAMES_OU.value},
        "games_under_175": {"selection_id":Selection.GAMES_UNDER_175.value,"market_id":Market.GAMES_OU.value},
        "games_under_185": {"selection_id":Selection.GAMES_UNDER_185.value,"market_id":Market.GAMES_OU.value},
        "games_under_195": {"selection_id":Selection.GAMES_UNDER_195.value,"market_id":Market.GAMES_OU.value},
        "games_under_205": {"selection_id":Selection.GAMES_UNDER_205.value,"market_id":Market.GAMES_OU.value},
        "games_under_215": {"selection_id":Selection.GAMES_UNDER_215.value,"market_id":Market.GAMES_OU.value},
        "games_under_225": {"selection_id":Selection.GAMES_UNDER_225.value,"market_id":Market.GAMES_OU.value},
        "games_under_235": {"selection_id":Selection.GAMES_UNDER_235.value,"market_id":Market.GAMES_OU.value},
        "games_under_245": {"selection_id":Selection.GAMES_UNDER_245.value,"market_id":Market.GAMES_OU.value},
        "games_under_255": {"selection_id":Selection.GAMES_UNDER_255.value,"market_id":Market.GAMES_OU.value},
        "games_under_265": {"selection_id":Selection.GAMES_UNDER_265.value,"market_id":Market.GAMES_OU.value},
        "games_under_275": {"selection_id":Selection.GAMES_UNDER_275.value,"market_id":Market.GAMES_OU.value},
        "games_under_285": {"selection_id":Selection.GAMES_UNDER_285.value,"market_id":Market.GAMES_OU.value},
        "games_under_295": {"selection_id":Selection.GAMES_UNDER_295.value,"market_id":Market.GAMES_OU.value},
        "games_under_305": {"selection_id":Selection.GAMES_UNDER_305.value,"market_id":Market.GAMES_OU.value},
        "games_under_315": {"selection_id":Selection.GAMES_UNDER_315.value,"market_id":Market.GAMES_OU.value},
        "games_under_335": {"selection_id":Selection.GAMES_UNDER_335.value,"market_id":Market.GAMES_OU.value},
        "games_under_345": {"selection_id":Selection.GAMES_UNDER_345.value,"market_id":Market.GAMES_OU.value},
        "games_under_355": {"selection_id":Selection.GAMES_UNDER_355.value,"market_id":Market.GAMES_OU.value},
        "games_under_365": {"selection_id":Selection.GAMES_UNDER_365.value,"market_id":Market.GAMES_OU.value},
        "games_under_375": {"selection_id":Selection.GAMES_UNDER_375.value,"market_id":Market.GAMES_OU.value},
        "games_under_385": {"selection_id":Selection.GAMES_UNDER_385.value,"market_id":Market.GAMES_OU.value},
        "games_under_395": {"selection_id":Selection.GAMES_UNDER_395.value,"market_id":Market.GAMES_OU.value},
        "games_under_405": {"selection_id":Selection.GAMES_UNDER_405.value,"market_id":Market.GAMES_OU.value},
        "games_under_415": {"selection_id":Selection.GAMES_UNDER_415.value,"market_id":Market.GAMES_OU.value},
        "games_under_425": {"selection_id":Selection.GAMES_UNDER_425.value,"market_id":Market.GAMES_OU.value},
        "games_under_435": {"selection_id":Selection.GAMES_UNDER_435.value,"market_id":Market.GAMES_OU.value},
        "games_under_455": {"selection_id":Selection.GAMES_UNDER_455.value,"market_id":Market.GAMES_OU.value},
        "games_under_465": {"selection_id":Selection.GAMES_UNDER_465.value,"market_id":Market.GAMES_OU.value},
        "player1_games_over_105": {"selection_id":Selection.PLAYER1_GAMES_OVER_105.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player1_games_over_115": {"selection_id":Selection.PLAYER1_GAMES_OVER_115.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player1_games_over_125": {"selection_id":Selection.PLAYER1_GAMES_OVER_125.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player1_games_over_185": {"selection_id":Selection.PLAYER1_GAMES_OVER_185.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player1_games_over_205": {"selection_id":Selection.PLAYER1_GAMES_OVER_205.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player1_games_under_105": {"selection_id":Selection.PLAYER1_GAMES_UNDER_105.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player1_games_under_115": {"selection_id":Selection.PLAYER1_GAMES_UNDER_115.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player1_games_under_125": {"selection_id":Selection.PLAYER1_GAMES_UNDER_125.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player1_games_under_185": {"selection_id":Selection.PLAYER1_GAMES_UNDER_185.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player1_games_under_205": {"selection_id":Selection.PLAYER1_GAMES_UNDER_205.value,"market_id":Market.PLAYER1_GAMES_OU.value},
        "player2_games_over_105": {"selection_id":Selection.PLAYER2_GAMES_OVER_105.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_over_115": {"selection_id":Selection.PLAYER2_GAMES_OVER_115.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_over_125": {"selection_id":Selection.PLAYER2_GAMES_OVER_125.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_over_165": {"selection_id":Selection.PLAYER2_GAMES_OVER_165.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_over_205": {"selection_id":Selection.PLAYER2_GAMES_OVER_205.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_over_75": {"selection_id":Selection.PLAYER2_GAMES_OVER_75.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_over_85": {"selection_id":Selection.PLAYER2_GAMES_OVER_85.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_over_95 ": {"selection_id":Selection.PLAYER2_GAMES_OVER_95.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_under_105": {"selection_id":Selection.PLAYER2_GAMES_UNDER_105.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_under_115": {"selection_id":Selection.PLAYER2_GAMES_UNDER_115.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_under_125": {"selection_id":Selection.PLAYER2_GAMES_UNDER_125.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_under_165": {"selection_id":Selection.PLAYER2_GAMES_UNDER_165.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_under_205": {"selection_id":Selection.PLAYER2_GAMES_UNDER_205.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_under_75": {"selection_id":Selection.PLAYER2_GAMES_UNDER_75.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_under_85": {"selection_id":Selection.PLAYER2_GAMES_UNDER_85.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "player2_games_under_95": {"selection_id":Selection.PLAYER2_GAMES_UNDER_95.value,"market_id":Market.PLAYER2_GAMES_OU.value},
        "set1_games_over_105": {"selection_id":Selection.SET1_GAMES_OVER_105.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_over_125": {"selection_id":Selection.SET1_GAMES_OVER_125.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_over_65": {"selection_id":Selection.SET1_GAMES_OVER_65.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_over_75": {"selection_id":Selection.SET1_GAMES_OVER_75.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_over_85": {"selection_id":Selection.SET1_GAMES_OVER_85.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_over_95": {"selection_id":Selection.SET1_GAMES_OVER_95.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_under_105": {"selection_id":Selection.SET1_GAMES_UNDER_105.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_under_125": {"selection_id":Selection.SET1_GAMES_UNDER_125.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_under_65": {"selection_id":Selection.SET1_GAMES_UNDER_65.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_under_75": {"selection_id":Selection.SET1_GAMES_UNDER_75.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_under_85": {"selection_id":Selection.SET1_GAMES_UNDER_85.value,"market_id":Market.SET1_GAMES_OU.value},
        "set1_games_under_95": {"selection_id":Selection.SET1_GAMES_UNDER_95.value,"market_id":Market.SET1_GAMES_OU.value},
        }