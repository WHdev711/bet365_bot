import scrapy
import orjson
from stars.items import Sport, CompetitionItem, EventItem, BookieOddItem, selections_db
import sys
import dateparser
import traceback
import datetime
import time

class StarsSpider(scrapy.Spider):
    name = "stars"
    ciclo = int(time.time())
    all_bookies = {54:"sports.pokerstarssports.it"}
    all_sports = {Sport.CALCIO.value:"SOCCER",Sport.TENNIS.value:"TENNIS",Sport.BASKET.value:"BASKETBALL",Sport.TENNISTAVOLO.value:"TABLE_TENNIS"}

    def start_requests(self):
        self.ciclo = int(time.time())
        for sport_id,sport_token in self.all_sports.items():
            for bookie_id,bookie_token in self.all_bookies.items():
                url = "https://{0}/sportsbook/v1/api/getSportTree?sport={1}&includeOutrights=false&includeEvents=false&channelId=3&locale=it-it&siteId=16".format(bookie_token,sport_token)
                yield scrapy.http.JsonRequest(url=url,callback=self.parse_competitions,cb_kwargs={"bookie_id":bookie_id,"sport_id":sport_id})

    def parse_competitions(self,response,bookie_id,sport_id):
        competitions_json = orjson.loads(response.text)
        
        for country in competitions_json["categories"]:
            for league in country["competition"]:
                yield CompetitionItem(
                    competition_name=league["name"].split("-")[-1].strip(),
                    country_name = league["name"].split("-")[0].strip(),
                    params=league["id"],
                    sport_id=sport_id,
                    bookie_id=bookie_id)
        
    def parse_events(self,response,competition_id,sport_id,bookie_id):
        competition_json = orjson.loads(response.text)
        for event in competition_json["event"]:
            if event["isInplay"] or event["state"] != "ACTIVE":
                continue
            event_id = str(event["id"])
            try:
                home, away = [team.strip() for team in event["name"].split(" vs ")]
            except Exception:
                continue
            
            # hour_diff = int(datetime.datetime.now(pytz.timezone('Europe/Rome')).utcoffset().total_seconds()/3600)-1
            hour_diff = 0
            open_date = (dateparser.parse(str(event["eventTime"]),settings={'TIMEZONE':'Europe/Rome'}) + datetime.timedelta(hours=hour_diff)).strftime("%Y-%m-%d %H:%M:%S")
            betradar_id = "NULL"

            for attribute in event["attributes"]["attrib"]:
                if attribute["key"] == "betradarId":
                    betradar_id = attribute["value"].split(":")[-1].strip()
                    break
            all_book_odds = {}
            if sport_id != Sport.CALCIO.value:
                for market in event["markets"]:
                    if market["name"] in ["Vincente incontro","Vincente incontro (Incl. OT)"] and market["suspended"] == False and market["displayed"] == True: 
                        for selection in market["selection"]:
                            if selection["suspended"] == False and float(selection["odds"]["dec"]) >= 1.01:
                                # if selection["name"] in [home] or selection["type"] in ["playerA", "AH", "A"]:
                                if selection["type"] in ["playerA", "AH", "A"]:
                                    all_book_odds["home_12"] = float(selection["odds"]["dec"])
                                # elif selection["name"] in [away] or selection["type"] in ["playerB","BH", "B"]:
                                elif selection["type"] in ["playerB","BH", "B"]:
                                    all_book_odds["away_12"] = float(selection["odds"]["dec"])

            yield EventItem(
                event_id = event_id,
                event = home+" v "+away,
                open_date = open_date,
                competition_id = competition_id,
                params = event_id,
                sport_id = sport_id,
                ciclo = self.ciclo,
                betradar_id = betradar_id,
                bookie_id = bookie_id,
                all_book_odds = all_book_odds)
                    
        competition_json.clear()

    def parse_odds(self,response,event_id,event_name,bookie_id):
        event_json = orjson.loads(response.text)
        if event_json["state"] == "ACTIVE":
            home,away=event_name.split(" v ")
            all_book_odds = {}
            for m in event_json["markets"]:
                if m["suspended"] == False and m["displayed"] == True:
                    if m["name"] == "Risultato esatto":
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                all_book_odds["cs_"+s["name"].replace("-","")] = float(s["odds"]["dec"])
                    elif m["name"] == "Doppia chance":
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                if s["name"] == home+" o pareggio":
                                    all_book_odds["dc_home_draw"] = float(s["odds"]["dec"])
                                elif s["name"] == home+" o "+away:
                                    all_book_odds["dc_home_away"] = float(s["odds"]["dec"])
                                elif s["name"] == away+" o pareggio":
                                    all_book_odds["dc_draw_away"] = float(s["odds"]["dec"])
                    elif m["name"] == "Doppia chance 1° tempo":
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                if s["name"] == home+" o pareggio":
                                    all_book_odds["fh_dc_home_draw"] = float(s["odds"]["dec"])
                                elif s["name"] == home+" o "+away:
                                    all_book_odds["fh_dc_home_away"] = float(s["odds"]["dec"])
                                elif s["name"] == away+" o pareggio":
                                    all_book_odds["fh_dc_draw_away"] = float(s["odds"]["dec"])
                    elif m["name"] == "Doppia chance 2° tempo":
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                if s["name"] == home+" o pareggio":
                                    all_book_odds["sh_dc_home_draw"] = float(s["odds"]["dec"])
                                elif s["name"] == home+" o "+away:
                                    all_book_odds["sh_dc_home_away"] = float(s["odds"]["dec"])
                                elif s["name"] == away+" o pareggio":
                                    all_book_odds["sh_dc_draw_away"] = float(s["odds"]["dec"])
                    elif m["name"] == "Totale goal":
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                all_book_odds[s["name"].lower().strip().replace(" ","_").replace(".","")] = float(s["odds"]["dec"])
                    elif m["name"] == "Totale goal 1° tempo":
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                all_book_odds["fh_"+s["name"].lower().strip().replace(" ","_").replace(".","")] = float(s["odds"]["dec"])
                    elif m["name"] == "Totale goal 2° tempo":
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                all_book_odds["sh_"+s["name"].lower().strip().replace(" ","_").replace(".","")] = float(s["odds"]["dec"])
                    elif m["name"] == "Totale goal "+home:
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                all_book_odds["team1_"+s["name"].lower().strip().replace(" ","_").replace(".","")] = float(s["odds"]["dec"])
                    elif m["name"] == "Totale goal "+away:
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                all_book_odds["team2_"+s["name"].lower().strip().replace(" ","_").replace(".","")] = float(s["odds"]["dec"])
                    elif m["name"].lower() == "risultato finale":
                        for selection in m["selection"]:
                            if selection["suspended"] == False and float(selection["odds"]["dec"]) >= 1.01:
                                if selection["type"].lower() == "a":
                                    all_book_odds["home"] = float(selection["odds"]["dec"])
                                elif selection["type"].lower() == "b":
                                    all_book_odds["away"] = float(selection["odds"]["dec"])
                                elif selection["name"] == "Draw" or selection["type"].lower() == "draw":
                                    all_book_odds["draw"] = float(selection["odds"]["dec"])
                    elif m["name"] == "Esito 1x2 1° tempo":
                        for selection in m["selection"]:
                            if selection["suspended"] == False and float(selection["odds"]["dec"]) >= 1.01:
                                if selection["type"].lower() == "a":
                                    all_book_odds["fh_home"] = float(selection["odds"]["dec"])
                                elif selection["type"].lower() == "b":
                                    all_book_odds["fh_away"] = float(selection["odds"]["dec"])
                                elif selection["name"] == "Draw" or selection["type"].lower() == "draw":
                                    all_book_odds["fh_draw"] = float(selection["odds"]["dec"])
                    elif m["name"] == "Esito 1x2 2° tempo":
                        for selection in m["selection"]:
                            if selection["suspended"] == False and float(selection["odds"]["dec"]) >= 1.01:
                                if selection["type"].lower() == "a":
                                    all_book_odds["sh_home"] = float(selection["odds"]["dec"])
                                elif selection["type"].lower() == "b":
                                    all_book_odds["sh_away"] = float(selection["odds"]["dec"])
                                elif selection["name"] == "Draw" or selection["type"].lower() == "draw":
                                    all_book_odds["sh_draw"] = float(selection["odds"]["dec"])
                    elif m["name"] == "Entrambe le squadre segnano":
                        for selection in m["selection"]:
                            if selection["suspended"] == False and float(selection["odds"]["dec"]) >= 1.01:
                                if selection["type"] == "No":
                                    all_book_odds["no_goal"] = float(selection["odds"]["dec"])
                                elif selection["type"] == "Yes":
                                    all_book_odds["goal"] = float(selection["odds"]["dec"])
                    elif m["name"] == "Entrambe le squadre segnano 1° tempo":
                        for selection in m["selection"]:
                            if selection["suspended"] == False and float(selection["odds"]["dec"]) >= 1.01:
                                if selection["type"] == "No":
                                    all_book_odds["fh_no_goal"] = float(selection["odds"]["dec"])
                                elif selection["type"] == "Yes":
                                    all_book_odds["fh_goal"] = float(selection["odds"]["dec"])
                    elif m["name"] == "Entrambe le squadre segnano 2° tempo":
                        for selection in m["selection"]:
                            if selection["suspended"] == False and float(selection["odds"]["dec"]) >= 1.01:
                                if selection["type"] == "No":
                                    all_book_odds["sh_no_goal"] = float(selection["odds"]["dec"])
                                elif selection["type"] == "Yes":
                                    all_book_odds["sh_goal"] = float(selection["odds"]["dec"])
                    elif m["name"] == "Rigore sì/no":
                        for selection in m["selection"]:
                            if selection["suspended"] == False and float(selection["odds"]["dec"]) >= 1.01:
                                if selection["type"] == "No":
                                    all_book_odds["no_penalty"] = float(selection["odds"]["dec"])
                                elif selection["type"] == "Yes":
                                    all_book_odds["penalty"] = float(selection["odds"]["dec"])
                    elif m["name"] == "Pari/dispari":
                        for selection in m["selection"]:
                            if selection["suspended"] == False and float(selection["odds"]["dec"]) >= 1.01:
                                if selection["type"] == "Even":
                                    all_book_odds["even"] = float(selection["odds"]["dec"])
                                elif selection["type"] == "Odd":
                                    all_book_odds["odd"] = float(selection["odds"]["dec"])
                    elif m["name"] == "Parziale/finale":
                        for s in m["selection"]:
                            if s["suspended"] == False and float(s["odds"]["dec"]) >= 1.01:
                                selection = "ht_ft_"+s["name"].replace("Pareggio","draw").replace(home,"home").replace(away,"away").replace(" / ","_")
                                all_book_odds[selection] = float(s["odds"]["dec"])
            
            for bet_type,odd_val in all_book_odds.items():
                if bet_type in selections_db:
                    sid = selections_db[bet_type]["selection_id"]
                    mid = selections_db[bet_type]["market_id"]
                    yield BookieOddItem(
                            bookie_id=bookie_id,
                            event_id=event_id,
                            selection_id=sid,
                            market_id=mid,
                            odd_value=odd_val,
                            ciclo=self.ciclo)

         